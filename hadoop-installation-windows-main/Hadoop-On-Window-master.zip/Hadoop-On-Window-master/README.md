# Hadoop Collection
In This repository you can learn 

* [How to install Hadoop 2.8.0 on Window 10](https://muhammadbilalyar.github.io/blogs/How-to-install-Hadoop-on-Window-10/)
* [How to Run Hadoop wordcount MapReduce Example on Windows 10](https://muhammadbilalyar.github.io/blogs/How-to-Run-Hadoop-wordcount-MapReduce-Example-on-Windows-10/)
